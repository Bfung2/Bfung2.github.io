<?php
$title = 'Products';
require_once __DIR__ . '/../includes/admin-header.php';

$products = all_products();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = post('action');

    if ($action === 'delete') {
        $products = array_values(array_filter($products, fn($p) => $p['id'] !== post('id')));
        write_json('products', $products);
        flash('Product deleted.');
        redirect('products.php');
    }

    $id  = post('id');
    $old = $id ? find_by_id($products, $id) : null;

    $row = [
        'id'       => $id ?: uid('p_'),
        'name'     => post('name'),
        'category' => post('category'),
        'price'    => (float)post('price'),
        'detail'   => post('detail'),
        'stock'    => post('stock'),
        'featured' => post('featured') === '1' ? 1 : 0,
        'image'    => handle_upload('image', $old['image'] ?? ''),
    ];

    if ($row['name'] === '') {
        flash('A product needs a name.');
    } else {
        if ($old) {
            foreach ($products as $i => $p) if ($p['id'] === $id) $products[$i] = $row;
            flash('Product saved.');
        } else {
            $products[] = $row;
            flash('Product added.');
        }
        write_json('products', $products);
    }
    redirect('products.php');
}

$edit = isset($_GET['edit']) ? find_by_id($products, $_GET['edit']) : null;
?>
<h1>Products</h1>
<p class="muted">Anything you sell off the shelf. These show on the Parts &amp; products page.</p>

<div class="panel" style="margin-bottom:32px">
  <h2 style="font-size:1.2rem"><?= $edit ? 'Edit ' . e($edit['name']) : 'Add a product' ?></h2>
  <form method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
    <div class="row2">
      <div class="field"><label for="name">Name</label><input id="name" type="text" name="name" value="<?= e($edit['name'] ?? '') ?>" required></div>
      <div class="field"><label for="category">Category</label><input id="category" type="text" name="category" list="cats" value="<?= e($edit['category'] ?? '') ?>" placeholder="e.g. Laptops, Peripherals">
        <datalist id="cats"><?php foreach (array_unique(array_filter(array_column($products, 'category'))) as $c): ?><option value="<?= e($c) ?>"><?php endforeach; ?></datalist>
      </div>
    </div>
    <div class="row2">
      <div class="field"><label for="price">Price</label><input id="price" type="number" step="0.01" min="0" name="price" value="<?= e($edit['price'] ?? '') ?>"></div>
      <div class="field"><label for="stock">Stock count</label><input id="stock" type="number" name="stock" value="<?= e($edit['stock'] ?? '') ?>" placeholder="Leave blank to always show as available"><div class="hint">Set to 0 to show it as out of stock.</div></div>
    </div>
    <div class="field"><label for="detail">Description</label><textarea id="detail" name="detail"><?= e($edit['detail'] ?? '') ?></textarea></div>
    <div class="field">
      <label for="image">Photo</label>
      <input id="image" type="file" name="image" accept="image/*">
      <?php if (!empty($edit['image'])): ?><div class="hint">Currently: <?= e($edit['image']) ?> — upload a new file to replace it.</div><?php endif; ?>
    </div>
    <label class="checkrow" style="margin-bottom:16px"><input type="checkbox" name="featured" value="1" <?= !empty($edit['featured']) ? 'checked' : '' ?>><span>Show this on the home page</span></label>
    <button class="btn" type="submit"><?= $edit ? 'Save changes' : 'Add product' ?></button>
    <?php if ($edit): ?><a class="btn btn-quiet" href="products.php">Cancel</a><?php endif; ?>
  </form>
</div>

<h2 style="font-size:1.2rem">All products (<?= count($products) ?>)</h2>
<?php if (!$products): ?>
  <div class="empty-state"><p>Nothing listed yet. Use the form above.</p></div>
<?php else: ?>
<div class="table-wrap">
  <table>
    <thead><tr><th></th><th>Name</th><th>Category</th><th class="num">Price</th><th class="num">Stock</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($products as $p): ?>
      <tr>
        <td style="width:64px"><?php if (!empty($p['image'])): ?><img src="../<?= e(img_url($p['image'])) ?>" alt="" style="width:52px;height:40px;object-fit:cover;border-radius:2px"><?php endif; ?></td>
        <td><strong><?= e($p['name']) ?></strong><?= !empty($p['featured']) ? ' <span class="tag tag-rec">home page</span>' : '' ?></td>
        <td><?= e($p['category'] ?? '') ?></td>
        <td class="num"><?= money($p['price']) ?></td>
        <td class="num"><?= ($p['stock'] ?? '') === '' ? '—' : (int)$p['stock'] ?></td>
        <td style="white-space:nowrap">
          <a class="btn btn-sm btn-quiet" href="products.php?edit=<?= e($p['id']) ?>">Edit</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Delete <?= e(addslashes($p['name'])) ?>?')">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= e($p['id']) ?>">
            <button class="btn btn-sm btn-danger" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
